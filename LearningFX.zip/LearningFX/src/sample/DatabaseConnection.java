package sample;

import java.sql.Connection;
import java.sql.DriverManager;


public class DatabaseConnection {
    public Connection databaseLink;

    public Connection getConnection() {
        String databaseName = "JavaFX";
        String databaseUser = "admin";
        String databasePassword = "administrator";
        String url = "jdbc:mysql://javafxdatabase.cbit3jlqpchl.us-east-1.rds.amazonaws.com/" + databaseName;

        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            databaseLink = DriverManager.getConnection(url, databaseUser, databasePassword);

        }catch(Exception e) {
            e.printStackTrace();
            e.getCause();
        }
        return databaseLink;
    }

}
